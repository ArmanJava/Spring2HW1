create definer = root@localhost trigger insert_employees
    after insert
    on employees
    for each row
BEGIN
    INSERT INTO salaries
    SET emp_no = NEW.emp_no, salary = 10000, from_date = NOW(), to_date = '9999-01-01';
  END;

